<?
include_once("class.bstCountdown.php");
$title = "Countdown Test Page";
$contents = getCnt();

print("<html><head><title>$title</title></head>\n");
print("<body><h1>$title</h1>\n");
print($contents);
print("</body></html>");

function getCnt()
{
    $cd = new bstCountdown(); // no category ID specified, will return all events in the table
    $r = $cd->formatCDowns(); // returns the formatted string of events
    
    return $r;
}

?>