# Note: I use PHPMyEdit (http://phpmyedit.sourceforge.net) to generate maintenance
#      screens for these simple tables. YMMV.

# cdEvents table:
CREATE TABLE 'cdEvents' (
'id' SMALLINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
'name' VARCHAR(75) NOT NULL,
'url' varchar(120) default NULL,
'tip' varchar(255) NULL,
'occurs_on' TIMESTAMP NOT NULL,
'category' SMALLINT DEFAULT '1' NOT NULL,
'active' ENUM('y','n') NOT NULL,
INDEX ('name', 'occurs_on', 'category', 'active')
);

#
# Sample data for table `cdEvents`
#

INSERT INTO cdEvents VALUES ('Anniversary', 'http://www.cheztj.com/', 'What a wonderful restaurant for a celebration!', '2002-10-30', 1, 'y');
INSERT INTO cdEvents VALUES ('Nemesis', 'http://nemesis.startrek.com/', '2002-12-13', 'Trek 10 is in theaters', 1, 'y');
INSERT INTO cdEvents VALUES ('The Shield', 'http://www.fxnetworks.com/shows/originals/the_shield/', '2003-01-07', 1, 'y');
INSERT INTO cdEvents VALUES ('Sammy Sosa', NULL, '1956-01-23', 2, 'y');
INSERT INTO cdEvents VALUES ('Jim Adams', NULL, '1954-02-20', 2, 'y');
INSERT INTO cdEvents VALUES ('Annie Oakley', NULL, '1984-03-19', 2, 'y');
INSERT INTO cdEvents VALUES ('Joanne Jacobs', NULL, '1964-04-14', 2, 'y');
INSERT INTO cdEvents VALUES ('Carlie Simon', NULL, '1978-04-30', 2, 'y');
INSERT INTO cdEvents VALUES ('Nancy Drew', NULL, '1961-06-13', 2, 'y');
INSERT INTO cdEvents VALUES ('Pam Anderson', NULL, '1960-07-10', 2, 'y');
INSERT INTO cdEvents VALUES ('Bill and Vivian', NULL, '2001-10-30', 3, 'y');
INSERT INTO cdEvents VALUES ('Richard and Bobbi', NULL, '1951-02-11', 3, 'y');
INSERT INTO cdEvents VALUES ('Vivian Leigh', NULL, '1967-08-10', 2, 'y');
INSERT INTO cdEvents VALUES ('Stephanie Zimbalist', NULL, '1988-09-28', 2, 'y');
INSERT INTO cdEvents VALUES ('Betsy Ross', NULL, '1966-12-23', 2, 'y');
INSERT INTO cdEvents VALUES ('Brian Wilson', NULL, '1967-08-25', 2, 'y');


# cdCategories table:
CREATE TABLE 'cdCategories' (
'id' SMALLINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
'category' VARCHAR(50) NOT NULL
)
COMMENT = 'Categories for the cdEvents table';
# This table isn't really necessary, not actually used in the current system,
# and simply keeps an organized list of the categories


#
# Sample data for table `cdCategories`
#

INSERT INTO cdCategories VALUES (1, 'main');
INSERT INTO cdCategories VALUES (2, 'birthdays');
INSERT INTO cdCategories VALUES (3, 'anniversaries');

# I use three basic categories:
# main - for the list on my site's front page
# birthdays
# anniversaries
