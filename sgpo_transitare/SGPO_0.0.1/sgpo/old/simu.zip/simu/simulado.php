<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Sistema Gestor de Provas Online [Simulado]</title>
<!-- Fun��es gerais de abstra��o de dados e tratamentos de telas -->
<script language="javascript" src="../js/jquery.js"></script>
<!-- script language="javascript1.5" type="text/javascript" src="./cronometro/javascript_timer.js"></script -->
<link href="css/prova_branco2.css" rel="stylesheet" type="text/css" />
<style type="text/css">

        <style type="text/css">
          <!--
          body {
                  margin-left: 2px;
                  margin-top: 2px;
                  margin-right: 2px;
                  margin-bottom: 2px;
          }

          .fundo{
                  background: url(images/lateral_fundo.jpg) repeat-y;
          }
          -->
        </style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body>

<div id="Layer1" style="position:absolute; left:738px; top:200px; width:69px; height:12px; z-index:1"> 
  <div> 
    <table width="150" border="0" cellpadding="0" cellspacing="0" bgcolor="#FF0000">
      <tr> 
        <td align="center"><font color="#FFFFFF" size="4"><strong>Aguarde...</strong></font></td>
      </tr>
    </table>
  </div>
</div>
<div align="center">
  <table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td><img src="images/topo_provaportal_770px.jpg" width="770" height="112" /></td>
    </tr>
    <tr>
      <td class="fundo"><table width="770" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="168" valign="top"><table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
                <tr> 
                  <td height="168" background="images/layout_limpo_01.jpg">&nbsp;</td>
                </tr>
              </table></td>
            <td width="589" rowspan="3" valign="top"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="88" valign="middle" background="images/topoprova02.jpg">
            <!-- Dados do candidato - inicio  -->
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
						  <tr>
							
                        <td id="td_candidato_dados_fundo" height="90" align="left"> 
                          <span id="sp_titulo" class="titulo" style="display: ">&nbsp;&nbsp;&nbsp;Simulado 
                          de Provas Online</span> 
                          <table id="tb_candidato_dados" width="550" border="0" cellspacing="3" cellpadding="0" 
						  		 style="display: ">
								  <tr>
									<td width="10" class="tela04instrucaotit" align="center">&nbsp;</td>
									<th height="15" class="tela04instrucaotit">Nome do Candidato&nbsp;&nbsp;</th>
									<th width="110" class="tela04instrucaotit">CPF</th>
									
                              <td width="50" rowspan="2" valign="top"> 
                                <div align="center"></div></td>
								  </tr>
								  <tr>
									<td align="center">&nbsp;</td>
									<td bgcolor="#FFFFFF" class="tela04respostas" id="tx_candidato_nome">nome nome nome nome nome nome nome nome </td>
									<td align="center" valign="top" nowrap="nowrap" bgcolor="#FFFFFF" class="tela04respostas" id="tx_candidato_cpf">999999999-99</td>
								  </tr>
							  </table>
						</td>
						  </tr>
						</table>
            <!-- Dados do candidato - fim  -->
					</td>
                </tr>
                <tr>
                  <td align="right" valign="top">&nbsp; </td>
                </tr>
            </table>
              <table width="100%" border="0" cellspacing="0" cellpadding="0"
			  		 style="display: none">
                <tr> 
                  <td height="355" valign="top" bgcolor="#00FFFF"> </td>
                </tr>
                <tr> 
                  <td height="60" valign="top" bgcolor="#FFFFCC">&nbsp;</td>
                </tr>
                <tr> 
                  <td>&nbsp;</td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td height="150" valign="top" class="fundo" > 
              <div align="left">
                <table id="tb_esquerdo" width="150" border="0" cellspacing="0" cellpadding="0"
						style="display: " >
                  <tr> 
                    <td width="81%"><div align="center" class="tela04instrucaotit">INSTRU&Ccedil;&Otilde;ES</div></td>
                    <td width="19%">&nbsp;</td>
                  </tr>
                  <tr> 
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr> 
                    <td><div align="center"> 
                        <table width="150" border="0" cellpadding="0" cellspacing="5" class="tela04instrucao">
                          <tr> 
                            <td valign="top"><div align="right">1)</div></td>
                            <td width="81%"><div align="left"> 
                                <p>Leia atentamente &agrave; <br />
                                  quest&atilde;o.</p>
                                <p>&nbsp;</p>
                              </div></td>
                          </tr>
                          <tr> 
                            <td valign="top"><div align="right">2)</div></td>
                            <td><div align="left"> 
                                <p>Clique com o mouse <br />
                                  sobre a alternativa <br />
                                  correta, ou digite a <br />
                                  letra correspondente <br />
                                  no espa&ccedil;o indicado.</p>
                                <p>&nbsp;</p>
                              </div></td>
                          </tr>
                          <tr> 
                            <td valign="top"><div align="right">3)</div></td>
                            <td><div align="left"> 
                                <p>&Eacute; poss&iacute;vel pular <br />
                                  uma quest&atilde;o e voltar <br />
                                  para respond&ecirc;-la <br />
                                  depois, clicando nas <br />
                                  setas ou no n&uacute;mero <br />
                                  correspondente &agrave; <br />
                                  quest&atilde;o.</p>
                                <p>&nbsp;</p>
                              </div></td>
                          </tr>
                          <tr> 
                            <td valign="top"><div align="right">4)</div></td>
                            <td><div align="left"> 
                                <p>O gabarito mostra <br />
                                  automaticamente as <br />
                                  quest&otilde;es que ja <br />
                                  foram respondidas.</p>
                                <p>&nbsp;</p>
                              </div></td>
                          </tr>
                        </table>
                      </div></td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr> 
                    <td align="center"> 
                      <table width="116" height="35" border="0" cellpadding="0" cellspacing="0">
                        <tr> 
                          <td height="25" align="center" background="images/relogio.jpg"> 
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="text" type="text" id="timetextarea" style="font-size:15px" value="00:00" size="6" />
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td>&nbsp;</td>
                  </tr>
                </table>
              </div></td>
          </tr>
          <tr>
            <td valign="bottom"><div align="left">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="center"><img id="img_logo" src="images/tela4_logodireita.gif" style="display: none" /></td>
                  </tr>
                  <tr>
                    <td background="images/layout_limpo_05.jpg">&nbsp;</td>
                  </tr>
                </table>
              </div></td>
          </tr>
          <tr align="right"> 
            <td height="50" colspan="2" valign="top" background="images/layout_limpo_06.jpg"><table border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr> 
                  <td>&nbsp;</td>
                  <td> <table border="0" cellpadding="0" cellspacing="0" class="tela04instrucao" id="tr_gabarito_opcoes" style="display: ">
                      <tr> 
                        <?
				$iQuantos = 31;
				for ($x=1; $x < $iQuantos; $x++) {
				?>
                        <td align="center"><img id="img_questao_<?=$x?>" src="images/nocheck.gif" width="20" height="20" /></td>
                        <?
				}
				?>
                      </tr>
                      <tr> 
                        <?
				for ($x=1; $x < $iQuantos; $x++) {
				?>
                        <td align="center"> <p>
                            <?=$x?>
                          </p></td>
                        <?
				}
				?>
                      </tr>
                    </table></td>
                  <td>&nbsp;</td>
                </tr>
              </table> </td>
          </tr>
      </table></td>
    </tr>
  </table>
</div>
</body>
</html>
