﻿
<!-- Tela de entrada / identifica��o do candidato -->

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="30">&nbsp;</td>
  </tr>
  <tr>
    <td align="center">
      <table border=0 align="center">
        <tr>
          <td width="521" height="149" align="center" background="images/tela3_avisobranco.gif"><font size="5" face="Verdana, Arial, Helvetica, sans-serif">
            Informe seu login/email e sua senha </font></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="50">&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><table border="0" bordercolor="#000000">
        <tr>
          <td align="right">EMail:</td>
          <td valign="top" bgcolor="#000000"><input name="campo1" type="text" id="campo1" value="" size=50 /></td>
        </tr>
        <tr>
          <td colspan="2" align="right">&nbsp;</td>
        </tr>
        <tr>
          <td align="right">Senha:</td>
          <td bgcolor="#000000"><input name="campo2" type="text" id="campo2" value="" size=50 /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr align="center">
          <td colspan="2"><img src="images/botaum_avancar.jpg" name="btn_Entrar" width="101" height="30" id="btn_Entrar" /></td>
        </tr>
      </table>

    </td>
  </tr>
  <tr>
    <td height="20" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td align="right">** Se ainda não possui uma senha, <strong> <font color="#0000FF">
      <input type="button" id="a_cadastrese" value="CADASTRE-SE">
      </font> </strong> gratuitamente.</td>
  </tr>
</table>

<!-- Prepara para receber o click no bot�o btn_Entrar e processa a pesquisa pelo candidato -->
<script src="./js/autentica.js.php"></script>