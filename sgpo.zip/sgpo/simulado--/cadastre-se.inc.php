<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Tecnodata Educacional</title>
</head>

<body>
<form name="form1" method="post" action="">
  <table width="50%" border="1">
    <tr>
      <th colspan="3"><h2>Cadastro </h2></th>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Nome:</td>
      <td><label>
        <input type="text" name="textfield">
      </label></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">E-Mail:</td>
      <td><input type="text" name="textfield2"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">CPF:</td>
      <td><input type="text" name="textfield3"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Data Nascimento: </td>
      <td><input type="text" name="textfield4"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Sexo:</td>
      <td><input type="text" name="textfield5"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Fones:</td>
      <td><input type="text" name="textfield6"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Endere&ccedil;o:</td>
      <td><input type="text" name="textfield7"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Bairro:</td>
      <td><input type="text" name="textfield8"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Cidade/UF:</td>
      <td><input type="text" name="textfield9"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">CEP:</td>
      <td><input type="text" name="textfield10"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2" align="right"><hr size="0"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Senha:</td>
      <td><input type="text" name="textfield12"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
</body>
</html>
