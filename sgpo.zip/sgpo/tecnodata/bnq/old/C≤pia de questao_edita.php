<div id="questao_edita">
  <h1>BNQ - Edi&ccedil;&atilde;o </h1>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td><h2>Parametros</h2></td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="4" cellpadding="0">
            <tr>
              <td width="50%" valign="top" class="tabelas"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><div align="center">Disciplina</div></td>
                  <td><div align="center">Dificuldade</div></td>
                  <td><div align="center">Natureza</div></td>
                  <td><div align="center">Assunto</div></td>
                  <td align="center">Status</td>
                  </tr>
                <tr>
                  <td><div align="center">
                    <select name="select2">
                    </select>
                  </div></td>
                  <td><div align="center">
                    <select name="select3">
                    </select>
                  </div></td>
                  <td><div align="center">
                    <select name="select4">
                    </select>
                  </div></td>
                  <td><div align="center">
                      <select name="select5">
                      </select>
                  </div></td>
                  <td><select name="select6">
                  </select></td>
                  </tr>
              </table></td>
              <td width="50%" align="center" valign="top" class="tabelas"><table width="90%" border="0" cellspacing="2" cellpadding="0">
                <tr>
                  <td colspan="2"><strong>Cursos vinculados &agrave; esta quest&atilde;o:</strong></td>
                </tr>
                <tr>
                  <td width="50%"><input type="checkbox" name="checkbox" value="checkbox" />
                    Instrutor</td>
                  <td><input type="checkbox" name="checkbox3" value="checkbox" />
                    Reciclagem</td>
                </tr>
                <tr>
                  <td><input type="checkbox" name="checkbox2" value="checkbox" />
                    Primeira Habilita&ccedil;&atilde;o </td>
                  <td><input type="checkbox" name="checkbox4" value="checkbox" />
                    Renova&ccedil;&atilde;o</td>
                </tr>
              </table></td>
            </tr>
          </table>
                <table width="100%" border="0" cellspacing="4" cellpadding="0">
                  <tr>
                    <td><h2>Pergunta:</h2></td>
                    <td><h2>Respostas:</h2></td>
                  </tr>
                  <tr>
                    <td width="50%" valign="top" class="tabelas"><table width="100%" border="0">
                        <tr>
                          <td><textarea name="textarea" cols="45" rows="10"></textarea></td>
                        </tr>
                        <tr>
                          <td height="40">Imagem:
                            <input name="file" type="file" /></td>
                        </tr>
                        <tr>
                          <td align="center" valign="top"><div id="img_pergunta" style="border: 1px solid ; height:75px; width:75px; overflow: auto;">teste</div></td>
                        </tr>
                    </table></td>
                    <td width="50%" valign="top" class="tabelas"><table width="100%" border="0" cellspacing="2" cellpadding="0">
                        <tr>
                          <td><table width="100%" border="0">
                              <tr>
                                <td> 01 - 
                                  Dispon&iacute;vel:
                                  <input name="radiobutton22" type="radio" value="0" />
                                  Correta:
                                  <input name="radiobutton22" type="radio" value="1" checked="checked" />
                                  Fixa:
                                  <input type="checkbox" name="checkbox9" value="checkbox" /></td>
                              </tr>
                              <tr>
                                <td><textarea name="textfield10" cols="45" rows="2"></textarea></td>
                              </tr>
                          </table></td>
                        </tr>
                        <tr>
                          <td><table width="100%" border="0">
                              <tr>
                                <td> 02 - 
                                  Dispon&iacute;vel:
                                  <input name="radiobutton22" type="radio" value="0" />
                                  Correta:
                                  <input name="radiobutton22" type="radio" value="1" checked="checked" />
                                  Fixa:
                                  <input type="checkbox" name="checkbox92" value="checkbox" />                                </td>
                              </tr>
                              <tr>
                                <td><textarea name="textarea2" cols="45" rows="2"></textarea></td>
                              </tr>
                          </table></td>
                        </tr>
                        <tr>
                          <td><table width="100%" border="0">
                              <tr>
                                <td> 03 - 
                                  Dispon&iacute;vel:
                                  <input name="radiobutton22" type="radio" value="0" />
                                  Correta:
                                  <input name="radiobutton22" type="radio" value="1" checked="checked" />
                                  Fixa:
                                  <input type="checkbox" name="checkbox93" value="checkbox" />                                </td>
                              </tr>
                              <tr>
                                <td><textarea name="textarea3" cols="45" rows="2"></textarea></td>
                              </tr>
                          </table></td>
                        </tr>
                        <tr>
                          <td><table width="100%" border="0">
                              <tr>
                                <td> 04 - 
                                  Dispon&iacute;vel:
                                  <input name="radiobutton22" type="radio" value="0" />
                                  Correta:
                                  <input name="radiobutton22" type="radio" value="1" checked="checked" />
                                  Fixa:
                                  <input type="checkbox" name="checkbox94" value="checkbox" />                                </td>
                              </tr>
                              <tr>
                                <td><textarea name="textarea4" cols="45" rows="2"></textarea></td>
                              </tr>
                          </table></td>
                        </tr>
                        <tr>
                          <td><table width="100%" border="0">
                              <tr>
                                <td> 05 - 
                                  Dispon&iacute;vel:
                                  <input name="radiobutton22" type="radio" value="0" />
                                  Correta:
                                  <input name="radiobutton22" type="radio" value="1" checked="checked" />
                                  Fixa:
                                  <input type="checkbox" name="checkbox95" value="checkbox" />                                </td>
                              </tr>
                              <tr>
                                <td><textarea name="textarea5" cols="45" rows="2"></textarea></td>
                              </tr>
                          </table></td>
                        </tr>
                    </table></td>
                  </tr>
              </table></td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="10" cellpadding="0">
            <tr>
              <td><div align="right">
                <input name="Submit" type="submit" class="botoes" value="SALVAR E FICAR" />
              </div></td>
              <td><div align="center">
                <input name="Submit2" type="submit" class="botoes" value="SALVAR E SAIR" />
              </div></td>
              <td><div align="left">
                <input name="Submit3" type="submit" class="botoes" value="SAIR SEM GRAVAR" />
              </div></td>
            </tr>
          </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>
