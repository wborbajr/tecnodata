$(document).ready(function(){

    // Carrega tela de indentifica��o do candidato
    $("#conteudo_meio").load("./login.inc.php");
	
});

function Mostra_Mensagem(status) {
    if (status=="on") {
	    $("#div_cargando").show('slow');
	} else {
	    $("#div_cargando").hide('slow');
	};
}
