<center>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="100" valign="top"><div align="center">
      <h1>RECUPERA&Ccedil;&Atilde;O DE SENHA</h1>
    </div></td>
  </tr>
  <tr>
    <td><div align="center"><strong>USUARIO</strong>
            <input id="campo1" type="text" class="obrigatorio" size="15" />
    </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center">
      <input id="btn_GerarSenha" type="button" class="botoes" value="Gerar nova senha" />
    </div><p>&nbsp;</p></td>
  </tr>
  <tr id="tr_senhagerada" style="display: none">
    <td height="20" bgcolor="red">
		<font color="#ffffff">
			ATEN&Ccedil;&Atilde;O!! Uma nova senha foi gerada e enviada para seu email.
		</font>
	</td>
  </tr>
</table>
</center>
<script>
$(document).ready(function(){

	$("#btn_GerarSenha").click(function(){
		//$("#conteudo_meio").load("./gerasenha.inc.php");
		$("#tr_senhagerada").show('slow');
	});

});
</script>