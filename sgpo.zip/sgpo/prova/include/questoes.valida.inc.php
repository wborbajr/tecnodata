<?
	session_start();

	$iOpcao			= $_REQUEST['iPos'];
	$iDir 			= $_REQUEST['iDir'];
	$iOpcao_checada = $_REQUEST['iOpcao_checada']-1;

	// Dire��o / Navega��o entre as quest�es
	if (isset($iDir)) {
		// $iDir pode ser negativo!!
    	$_SESSION[iDirecao] = ( $_SESSION[iDirecao] + ($iDir) );

    }

    // Grava a op��o selecionada para posterior restaura��o
    if (isset($iOpcao_checada)) {
    	// Desmarca todos
    	for ($x = 0; $x < $_SESSION[prova][param_nr_alternativas]; $x++) {
			$_SESSION[opcoes][$iOpcao][$x][3] = 0;
		};

		// Seta a op��o escolhida
		$_SESSION[opcoes][$iOpcao][$iOpcao_checada][3] = 1;
	}

echo $_SESSION[opcoes][$iOpcao][$iOpcao_checada][3].' - '.$iPos;
return false;
?>