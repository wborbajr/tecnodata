<?php	
	// Setup Database
	mysql_connect ('localhost', 'database_username', 'database_password');
	mysql_select_db ('database_name');
?>