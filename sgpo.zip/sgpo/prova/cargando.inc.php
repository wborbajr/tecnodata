<style type="text/css">
<!--
.style6 {	font-size: 18px;
	color: #FF0000;
}
.style7 {color: #FFFFFF}
-->
</style>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="80">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center" class="tela02tit">Validando Informa&ccedil;&atilde;o do Usu&aacute;rio </div></td>
  </tr>
  <tr>
    <td height="50">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="175">&nbsp;</td>
          <th width="250" height="46" background="imagens/recortes/images/tela2_campo2.gif" class="style6 style7"  style="background-repeat: no-repeat">
		  <span id="td_cargando">CARGANDO...</span></th>
          <td width="182">&nbsp;</td>
        </tr>
        <tr>
          <td height="25" colspan="3">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td height="46">&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td height="40">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"></div></td>
  </tr>
</table>
<!-- js -->
<script src="./js/cargando.js.php"></script>