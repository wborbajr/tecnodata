<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Tecnodata Educacional</title>
</head>

<body>
<form name="form1" method="post" action="">
<center>
  <table border="0" align="center" bgcolor="#ECE9D8">
    <tr>
      <th colspan="3"><h2>Cadastro </h2></th>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2" align="right"><hr size="0"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Nome:</td>
      <td><label>
        <input name="textfield" type="text" size="50">
      </label></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">E-Mail:</td>
      <td><input name="textfield2" type="text" size="50"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">CPF:</td>
      <td><input name="textfield3" type="text" size="50"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Data Nascimento: </td>
      <td><input type="text" name="textfield4"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Sexo:</td>
      <td><p>
          <input name="rdgSexo" type="radio" value="M" checked>
          Masculino</label>
          <input name="rdgSexo" type="radio" value="F">
          Feminino
      </p></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Fones:</td>
      <td><input name="textfield6" type="text" size="50"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Endere&ccedil;o:</td>
      <td><input name="textfield7" type="text" size="50"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Bairro:</td>
      <td><input name="textfield8" type="text" size="50"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Cidade/UF:</td>
      <td><input name="textfield9" type="text" size="50"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">CEP:</td>
      <td><input type="text" name="textfield10"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2" align="right"><hr size="0"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">Senha:</td>
      <td><input type="text" name="textfield12"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <th colspan="2" align="center">Como tomou conhecimento deste Simulador de Provas Online ? </th>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2" align="center"><hr size="0"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2" align="center"><table width="95%" border="0">

        <tr>
          <td align="center"><table>
            <tr>
              <td><label>
                <input type="radio" name="RadioGroup1" value="Buscadores">
                Buscadores (Google, Yahoo, ...)</label></td>
              <td><label>
              <input type="radio" name="RadioGroup1" value="Radio_TV">
R&aacute;dio / TV</label></td>
            </tr>
            <tr>
              <td><label>
                <input type="radio" name="RadioGroup1" value="Auto_Escola">
                Auto Escola</label></td>
              <td><input type="radio" name="RadioGroup1" value="Folder_Cartazes">
Folder / Cartazes</td>
            </tr>
            <tr>
              <td><label>
                <input type="radio" name="RadioGroup1" value="Material_Didatico">
                Material Did�tico</label></td>
              <td><input type="radio" name="RadioGroup1" value="Jornais">
Jornais</td>
            </tr>
            <tr>
              <td><label>
                <input type="radio" name="RadioGroup1" value="Amigo_Indicacao">
                Amigo / Indica&ccedil;&atilde;o</label></td>
              <td><input type="radio" name="RadioGroup1" value="Email">
Email</td>
            </tr>
            <tr>
              <td colspan="2"><label>
                <input type="radio" name="RadioGroup1" value="Outros">
Outros
<input name="textfield92" type="text" size="50">
              </label></td>
              </tr>
          </table>          </td>
          </tr>

      </table></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2" align="right"><hr size="0"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2" align="center"><input type="submit" name="Submit" value="Enviar"></td>
    </tr>
  </table>
</center>
</form>
</body>
</html>
