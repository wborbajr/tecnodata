<?
$rssurl[] = array( 'Not�cias RNP',     'http://www.rnp.br/noticias/rss.xml');
$rssurl[] = array( 'RNP na M�dia', 	   'http://www.rnp.br/noticias/imprensa/rss.xml');
$rssurl[] = array( 'Alertas do CAIS',  'http://www.rnp.br/cais/alertas/rss.xml');
$rssurl[] = array( 'Social - Aprendiz', 'http://www.rssficado.com.br/xml.php?aprendiz.xml');
$rssurl[] = array( 'Pol�tica - Hora do Povo', 	   'http://www.rssficado.com.br/xml.php?horadopovo.xml');
$rssurl[] = array( 'Pol�tica - Correio dos Municipios', 'http://www.correiodosmunicipios.com.br/rss091.xml');
$rssurl[] = array( 'Folha - Brasil', 'http://feeds.folha.uol.com.br/folha/brasil/rss091.xml');
$rssurl[] = array( 'Folha - Ci�ncia', 'http://feeds.folha.uol.com.br/folha/ciencia/rss091.xml');
$rssurl[] = array( 'Folha - Cotidiano', 'http://feeds.folha.uol.com.br/folha/cotidiano/rss091.xml');
$rssurl[] = array( 'Folha - Dinheiro', 'http://feeds.folha.uol.com.br/folha/dinheiro/rss091.xml');
$rssurl[] = array( 'Folha - Esporte', 'http://feeds.folha.uol.com.br/folha/esporte/rss091.xml');
$rssurl[] = array( 'Folha - Inform�tica', 'http://feeds.folha.uol.com.br/folha/informatica/rss091.xml');
$rssurl[] = array( 'Folha - Mundo', 'http://feeds.folha.uol.com.br/folha/mundo/rss091.xml');
$rssurl[] = array( 'Tecnologia - Plant�o� Info', 'http://www.rssficado.com.br/xml.php?plantaoinfo.xml');
$rssurl[] = array( 'Tecnologia - Web Insider', 'http://www.webinsider.com.br/feed.php/rss');
$rssurl[] = array( 'LinuxDicas - Artigos, Dicas e Not&iacute;cias Sobre Linux',  'http://www.linuxdicas.com.br/backend.php');
$rssurl[] = array( 'Linux - OLinux Not�cias',  'http://www.rssficado.com.br/xml.php?olinux.xml');
$rssurl[] = array( 'Linux - Linux Clube :: Noticias', 'http://www.linuxclube.com.br/rss/noticias.php');
$rssurl[] = array( 'Linux - Not�cias Linux', 'http://www.noticiaslinux.com.br/rss.php');
$rssurl[] = array( 'Linux - BR-Linux.org - Linux levado a s�rio desde 1996', 'http://br-linux.org/rss/brlinux-iso.xml');
$rssurl[] = array( 'Linux - Projeto Kurumin Turbo', 'http://kurumin-turbo.codigolivre.org.br/index2.php?option=com_rss&no_html=1');
$rssurl[] = array( 'Programa��o - php.net', 'http://www.php.net/news.rss');
?>