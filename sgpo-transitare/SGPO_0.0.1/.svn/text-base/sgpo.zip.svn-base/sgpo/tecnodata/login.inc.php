<center>
<table border="0" align="center" cellpadding="0" cellspacing="3">
  <tr>
    <td colspan="4"><img src="../imagens/logomarca_color.gif" width="160" height="60" /></td>
  </tr>
  <tr>
    <td width="18%">&nbsp;</td>
    <td width="18%">&nbsp;</td>
    <td width="33%">&nbsp;</td>
    <td width="31%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="right"><strong>USUARIO</strong></div></td>
    <td><input id="campo1" type="text" class="obrigatorio" value="1@1" /></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="right"><strong>SENHA</strong></div></td>
    <td><input id="campo2" type="password" class="obrigatorio" value="11"/></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4"><div align="center">
      <input id="btn_Entrar" type="submit" class="botoes" value="ENTRAR" />
    </div></td>
  </tr>
  <tr>
    <td colspan="4"><div align="center"></div></td>
  </tr>
  <tr>
    <td colspan="4"><div align="center"><a id="a_gerasenha" href="#">esqueceu a senha?</a></div></td>
  </tr>
</table>
</center>
<!-- Carrega tela de primeira identifica��o do candidato -->
<script language="javascript" src="./js/login.js.php"></script>
