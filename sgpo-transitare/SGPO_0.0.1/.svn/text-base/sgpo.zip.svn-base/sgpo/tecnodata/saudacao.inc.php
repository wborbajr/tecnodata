<div id="corpo">
		<div id="menu">
			<ul>
			  <li><a href="cliente.html">Cliente</a></li>
			  <li><a href="bnqcad.html">BNQ</a></li>
			  <li><a href="#">Bilhetagem</a></li>
			  <li><a href="#">Simulado</a></li>
			  <li><a href="#">Usu�rios</a></li>
			</ul>		
		</div>
		<div id="conteudo">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="300"><div align="center">
                  <h1>BEM VINDO! </h1>
                </div></td>
              </tr>
            </table>
			<p>&nbsp;</p>
	  </div>
	</div>