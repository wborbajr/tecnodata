<?
	session_start();

	// Direção / Navegação entre as questões
   	$_SESSION[iDirecao] = $_REQUEST['iDir'];
?>