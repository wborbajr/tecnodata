
<!-- Tela de entrada / identifica��o do candidato -->

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="80">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><img src="imagens/recortes/images/tela1_aviso.gif" width="521" height="149" /></div></td>
  </tr>
  <tr>
    <td height="50">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="175">&nbsp;</td>
          <td width="209" height="46" background="imagens/recortes/images/tela1_campo.gif" style="background-repeat:no-repeat"><div align="center">
            <input name="tx_renach" type="text" id="tx_renach" />
          </div>
          <td width="182">&nbsp;</td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td height="40">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center">
      <img src="imagens/recortes/images/avanca.gif" name="btn_Entrar" width="110" height="32" id="btn_Entrar" />
	  </div></td>
  </tr>
</table>

<!-- Prepara para receber o click no bot�o btn_Entrar e processa a pesquisa pelo candidato -->
<script src="./js/renach.js.php"></script>