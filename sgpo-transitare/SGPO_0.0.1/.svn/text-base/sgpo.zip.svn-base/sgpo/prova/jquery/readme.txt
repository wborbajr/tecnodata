Ajax Messages by Marc Grabanski
http://marcgrabanski.com/code/ajax-messages/

1) Use the create-table.sql to create the table on your MySQL database
2) Open db.php and edit it to your details (database name, username, password)

Thats it! Please send questions and comments to m@marcgrabanski.com
